<?php


/**
 * @package plugin run one
 * Deactivation
 */

namespace PluginRunTwo\Base;

class DeactivatePlugin
{

	public static function deactivate()
	{
            // deactivation functions
	}
}
