<?php


/**
 * @package PluginRunTwo
 */

namespace PluginRunTwo\Api\Callbacks;

class CardManagerCallbacks
{
    public function adminViewCard()
    {
//        echo '<div id="onecardapp"></div>';
    }
}
